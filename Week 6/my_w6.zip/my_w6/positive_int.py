def main():
    i = get_pos_int()
    print(i)

def get_pos_int():
    while True:
        n = int(input("Pos int: "))
        if n > 0:
            break
    return n

main()