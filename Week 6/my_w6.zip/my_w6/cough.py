def main():
    for i in range(3):
        cough()

def cough():
    print('cough')

main()