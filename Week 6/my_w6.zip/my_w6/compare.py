x = int(input("x: "))
y = int(input("y: "))

if x < y:
    print('x is less than y')
elif x > y:
    print('x is more than y')
else:
    print('x is equal to y')