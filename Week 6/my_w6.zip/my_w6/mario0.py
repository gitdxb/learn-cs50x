# count = 1
for i in range(3):
    for j in range(3):
        print('#', end='')
    print()
    #count += 1