scores = list()
scores.append(72)
scores.append(73)
scores.append(33)

print(f'Average: {sum(scores) / len(scores)}')