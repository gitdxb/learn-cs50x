import re

s = input("Do you agree? ")

if re.search('^y(es)?$', s, re.IGNORECASE):
    print('agree')
elif re.search('^no?$', s, re.IGNORECASE):
    print('disagree')