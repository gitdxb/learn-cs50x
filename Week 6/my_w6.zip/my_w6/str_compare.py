s = input('s: ')
t = input('t: ')

if s == t:
    print('same')
else:
    print('different')