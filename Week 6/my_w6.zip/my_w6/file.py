import csv

file = open('phonebook.csv', 'a')

name = input('name: ')
number = int(input('number: '))

writer = csv.writer(file)
writer.writerow((name, number))

file.close()

# Open with `with`: with open('phonebook.csv', 'a') as file