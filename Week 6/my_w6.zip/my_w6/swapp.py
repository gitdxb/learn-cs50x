x = int(input('x: '))
y = int(input('y: '))

print('x is:',x,'. y is:',y)
x, y = y, x
print('x is:',x,'. y is:',y)
print('x is {%x}, y is {%y}', x,y)