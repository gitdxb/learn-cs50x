s = input('s: ')

t = s

t  = t.capitalize()

print(f's: {s}')
print(f't: {t}')