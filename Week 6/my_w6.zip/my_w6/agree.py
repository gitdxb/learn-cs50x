s = input('Do you agree? ')

if s.lower() in ['y']:
    print('agree.')
elif s.lower() in ['n']:
    print('not agree.')