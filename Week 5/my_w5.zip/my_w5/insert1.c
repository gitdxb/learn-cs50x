// Insert to random position
#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node* next;
}
Node;

struct Node* head; // Set the head of the list
void Insert(int data, int position);
void Print();

int main(void)
{
    head = NULL;
    Insert(2,1); // insert 2 at pos 1
    Insert(3,2); // insert 3 at pos 2
    Insert(4,1); // List: 4,2,3
    Insert(5,1); // List: 5,4,2,3
    Print();
}

void Insert(int data, int position)
{
    Node* tmp1 = malloc(sizeof(Node));
    tmp1->data = data;
    tmp1->next = NULL;
    if (position == 1)
    {
        tmp1->next = head;
        head = tmp1;
        return;
    }
    Node* tmp2 = head;
    for (int i = 0; i < position - 2; i++)
    {
        tmp2 = tmp2->next;
    }
    tmp1->next = tmp2->next;
    tmp2->next = tmp1;
}

void Print()
{
    Node* tmp = head;
    while (tmp != NULL)
    {
        printf(" %i", tmp->data);
        tmp = tmp->next;
    }
    printf("\n");
}