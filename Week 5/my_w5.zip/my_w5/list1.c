#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node* next;
}
node;

void Insert(int x);
void Print();

struct node* head;
int main(void)
{
    head = NULL; // create an empty list
    printf("How many numbers? ");
    int n, i, x;
    scanf("%i", &n);
    for (i = 0; i < n; i++)
    {
        printf("Enter the number: ");
        scanf("%i", &x);
        Insert(x);
        Print();
    }
}

void Insert(int x)
{
    node* tmp = malloc(sizeof(node));
    tmp->data = x;
    //tmp->next = NULL;
    tmp->next = head;
    /*
    if (head != NULL)
    {
        tmp->next = head;  // if the list already exists
    }
    */
    head = tmp; // if head if empty
}

void Print()
{
    struct node* tmp = head;
    printf("List is: ");
    while (tmp != NULL)
    {
        printf(" %i", tmp->data);
        tmp = tmp->next;
    }
    printf("\n");
}