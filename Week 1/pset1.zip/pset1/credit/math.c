#include <cs50.h>
#include <stdio.h>
#include <math.h>

// Test with 4003600000000014
int main(void)
{
    int digit1, total1 = 0, digit2, sdigit2, total2 = 0, stotal2 = 0, checksum = 0;
    long input;

    do
    {
        input = get_long("Number: ");
    }
    while (input < 1);

    int x = input/pow(10,13); // AMEX: 34, 37
    int y = input/pow(10,14); // Mastercard: 51,52,53,54,55
    int z = input/pow(10,12); // Visa: 4
    int w = input/pow(10,15); // Visa: 4

    // Counting length
    int lgt = floor(log10(input)) + 1;

    // Split into 2 lists of number, make checksum
    for (int i = 0; i < lgt; i++)
    {
        if (i % 2 == 0)
        {
            digit1 = input % 10;
            total1 += digit1;
        }
        else
        {
            // Taking only from 2nd-to-last position and multiply by 2
            digit2 = (input % 10)*2;
            if (digit2 >= 10)
            {
                for (int j = 0; j < 2; j++)
                {
                    sdigit2 = digit2 % 10;
                    digit2 /= 10;
                    stotal2 += sdigit2;
                }
            }
            else
            {
                total2 += digit2;
            }
        }
        input /= 10;
    }
    total2 += stotal2;
    checksum = total1 + total2;

    // Check if checksum (or card number) is valid, print card type
    if (checksum % 10 == 0)
    {
        if (lgt == 15 && (x == 34 || x == 37))
        {
           printf("AMEX\n");
        }
        else if (lgt == 16 && (y == 51 || y == 52 || y == 53 || y == 54 || y == 55))
        {
            printf("MASTERCARD\n");
        }
        else if ((lgt == 13 && z == 4) || (lgt == 16 & w == 4))
        {
            printf("VISA\n");
        }
    }
    else
    {
       printf("INVALID\n");
    }
}